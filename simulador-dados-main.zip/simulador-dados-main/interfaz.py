INTERFAZ = """

#####################################
### SCRIPT DE SIMULACION DE DADOS ###
#####################################

Este script simula la tirada de un dado

"""

INTERFAZ_FINAL = "¿Quieres seguir tirando? ---> "

LISTA_TIRADAS = "Tus tiradas han sido: "
TOTAL_TIRADAS = "El total de tus tiradas es: "